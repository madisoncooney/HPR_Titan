/*
  Test.h - Test library for Wiring - description
  Copyright (c) 2006 John Doe.  All right reserved.
*/

// ensure this library description is only included once
#ifndef HPDF_h
#define HPDF_h

//Define baseclock in millis
#define HPDF_BCLK 50

///
/// Library definition
///
class HPDF {

public:

  struct HPDFFrameData
  {

    byte A;
    byte B;
    byte C;
    byte D;

  };

  struct HPDFFrameControl
  {

    byte stream;
    byte sensor; //actually 5 bits
    byte feed; //actually 3 bits

  };

  struct HPDFfloat
  {

    int sign;
    int exponent;
    int significand1;
    int significand2;
    int significand3;
    int significand4;
    int significand5;
    int significand6;

  };

  void sendPacket(HPDF::HPDFFrameControl control,HPDF::HPDFFrameData data);

private:

  int val(char c);
  int toDeci(char *str,int base);
  byte decimalToNibble(int n);
  byte joinNibble(byte n1, byte n2);
  byte joinNibbleStream(byte n1, byte n2);
  HPDF::HPDFfloat floatToComponents(float f);
  HPDF::HPDFFrameData createFrameData(int posneg,int exponent,int significand1,int significand2,int significand3,int significand4,int significand5,int significand6,int channel);
  HPDF::HPDFFrameControl createFrameControl(char sensorN[], int feedN);
  void sendFrameTerminator();

};

//Sensor class
class Sensor {

public:
  char *id;
  bool enabled;
  void (*apiRead)(); //Sensor.apiRead = &somefunction; ,, Function defined by sensor OEM that reads data from sensor
  int freq; //Hz
  int wait;

  Sensor(char *identification, int frequency = 50);

};

//Feed class
class Feed {

public:
  int id, sensorID, channel;
  float (*source)(); //Feed.source = &somefunction;  ,, Function defined by us that returns a single float from an apiFeed read
  HPDF::HPDFFrameControl control;

  Feed(int parentID, int identification);

  void transmit();

};

#endif
